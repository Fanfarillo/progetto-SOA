//QUESTO PROGRAMMA NON FA ALTRO CHE INSTALLARE ALL'INTERNO DEL SISTEMA UN DRIVER CHE MANDA DEI MESSAGGI IN PRINTK.

/*  
 *  baseline char device driver with limitation on minor numbers - no actual operations 
 */

#define EXPORT_SYMTAB
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/sched.h>	
#include <linux/pid.h>		/* For pid types */
#include <linux/tty.h>		/* For the tty declarations */
#include <linux/version.h>	/* For LINUX_VERSION_CODE */


MODULE_LICENSE("GPL");
MODULE_AUTHOR("Francesco Quaglia");

#define MODNAME "CHAR DEV"


// file operations definite; tutte le altre sono NON definite (anche se in realtà abbiamo anche l'implementazione di dev_read())
static int dev_open(struct inode *, struct file *);
static int dev_release(struct inode *, struct file *);
static ssize_t dev_write(struct file *, const char *, size_t, loff_t *);

#define DEVICE_NAME "my-new-dev"  /* Device file name in /dev/ - not mandatory  */


static int Major;            /* Major number assigned to broadcast device driver */


static DEFINE_MUTEX(device_state);

/* the actual driver */


static int dev_open(struct inode *inode, struct file *file) {

// this device file is single instance
   if (!mutex_trylock(&device_state)) { // si tenta di prelevare il mutex in maniera non bloccante per la dev_open(); questo vuol dire che il driver può essere aperto per un'unica sessione per volta
		return -EBUSY;
   }

   printk("%s: device file successfully opened by thread %d\n",MODNAME,current->pid);
//device opened by a default nop
   return 0;
}


static int dev_release(struct inode *inode, struct file *file) {

   mutex_unlock(&device_state); // si rilascia il medesimo mutex prelevato nella dev_open()

   printk("%s: device file closed by thread %d\n",MODNAME,current->pid);
//device closed by default nop
   return 0;

}



static ssize_t dev_write(struct file *filp, const char *buff, size_t len, loff_t *off) {
/* 1° PARAMETRO: puntatore alla struttura dati che rappresenta la sessione corrente; nella corrispondente syscall, al suo posto, abbiamo il codice numerico del canale di I/O che si sta per utilizzare
 * 2° PARAMETRO: buffer di memoria applicativa da cui vengono presi i dati da scrivere
 * 3° PARAMETRO: taglia del buffer
 * 4* PARAMETRO: puntatore all'interno della tabella filp che indica il punto esatto (l'offset) in cui stiamo lavorando
 */

#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 0, 0)
   printk("%s: somebody called a write on dev with [major,minor] number [%d,%d]\n",MODNAME,MAJOR(filp->f_inode->i_rdev),MINOR(filp->f_inode->i_rdev));
#else
   printk("%s: somebody called a write on dev with [major,minor] number [%d,%d]\n",MODNAME,MAJOR(filp->f_dentry->d_inode->i_rdev),MINOR(filp->f_dentry->d_inode->i_rdev));
#endif
//  return len;
  return 1;

}

static ssize_t dev_read(struct file *filp, char *buff, size_t len, loff_t *off) {

#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 0, 0)
   printk("%s: somebody called a read on dev with [major,minor] number [%d,%d]\n",MODNAME,MAJOR(filp->f_inode->i_rdev),MINOR(filp->f_inode->i_rdev));
#else
   printk("%s: somebody called a read on dev with [major,minor] number [%d,%d]\n",MODNAME,MAJOR(filp->f_dentry->d_inode->i_rdev),MINOR(filp->f_dentry->d_inode->i_rdev));
#endif
   return 0; // restituendo 0, non sto consegnando nulla al chiamante/al livello applicativo. Notiamo come le file operation, in questo esempio di codice così semplice, sono dummy (eseguono solo printk())

}


static struct file_operations fops = {
  .write = dev_write,
  .read = dev_read,
  .open =  dev_open,
  .release = dev_release
};



int init_module(void) {

	Major = __register_chrdev(0, 0, 256, DEVICE_NAME, &fops); // registrazione del char device driver
	/* 1° PARAMETRO (0): il major number viene scelto dal kernel
	 * 2° PARAMETRO (0): i minor number possono partire da 0
	 * 3° PARAMETRO (256): possono essere utilizzati fino a 256 minor number diversi
	 */

	if (Major < 0) {
	  printk("%s: registering device failed\n",MODNAME);
	  return Major;
	}

	printk(KERN_INFO "%s: new device registered, it is assigned major number %d\n",MODNAME, Major);

	return 0;
}

void cleanup_module(void) {

	unregister_chrdev(Major, DEVICE_NAME); // de-registrazione del char device driver

	printk(KERN_INFO "%s: new device unregistered, it was assigned major number %d\n",MODNAME, Major);

	return;

}
