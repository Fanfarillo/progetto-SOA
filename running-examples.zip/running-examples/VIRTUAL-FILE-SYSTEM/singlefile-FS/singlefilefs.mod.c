#include <linux/build-salt.h>
#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(.gnu.linkonce.this_module) = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section(__versions) = {
	{ 0xdd8f8694, "module_layout" },
	{ 0xd9b85ef6, "lockref_get" },
	{ 0x7f8e6631, "mount_bdev" },
	{ 0x7dc91601, "d_add" },
	{ 0xb44ad4b3, "_copy_to_user" },
	{ 0xeedbb59d, "__bread_gfp" },
	{ 0xc5850110, "printk" },
	{ 0x9ec6ca96, "ktime_get_real_ts64" },
	{ 0xe2a65c8b, "set_nlink" },
	{ 0x35b06543, "__brelse" },
	{ 0xdecd0b29, "__stack_chk_fail" },
	{ 0xdf7e758f, "unlock_new_inode" },
	{ 0x1ec0e286, "kill_block_super" },
	{ 0x2ea2c95c, "__x86_indirect_thunk_rax" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x51b7ed3b, "register_filesystem" },
	{ 0x9456ee39, "iput" },
	{ 0x1cb7a17d, "d_make_root" },
	{ 0x8e23176b, "unregister_filesystem" },
	{ 0x88db9f48, "__check_object_size" },
	{ 0xf440e787, "iget_locked" },
	{ 0x64669989, "inode_init_owner" },
};

MODULE_INFO(depends, "");


MODULE_INFO(srcversion, "C5D25F996C795F048AD38DF");
