#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <sys/ioctl.h>

int i;
char buff[4096];
#define DATA "ciao a tutti\n"
#define SIZE strlen(DATA)

void * the_thread(void* path){ // funzione eseguita dal thread creato per gestire l'i-esimo nodo I/O

	char* device;
	int fd;

	device = (char*)path;
	sleep(1);

	printf("opening device %s\n",device); // device = dispositivo di I/O associato all'i-esima iterazione del ciclo for all'interno del main
	fd = open(device,O_RDWR);
	if(fd == -1) {
		printf("open error on device %s\n",device);
		return NULL;
	}
	printf("device %s successfully opened\n",device);
	ioctl(fd,1);
	for(i=0;i<1000;i++) write(fd,DATA,SIZE); // scrittura di dati arbitrari
	return NULL; /* stiamo ritornando senza eseguire alcuna close(): alla terminazione del thread, la sessione sul singolo oggetto di I/O rimane aperta. Perciò, con la limitazione a una sessione sui
	* singoli oggetti, non possiamo avere più di un'istanza di user funzionante
	*/
}
int main(int argc, char** argv){

     int ret;
     int major;
     int minors;
     char *path;
     pthread_t tid;

     if(argc<4){
	printf("useg: prog pathname major minors\n"); // dobbiamo avere un pathname, un major number e un certo numero di minor number da gestire
	return -1;
     }

     path = argv[1];
     major = strtol(argv[2],NULL,10);
     minors = strtol(argv[3],NULL,10);
     printf("creating %d minors for device %s with major %d\n",minors,path,major);

     for(i=0;i<minors;i++){
	sprintf(buff,"mknod %s%d c %d %i\n",path,i,major,i); // definizione del comando che istanzia un nuovo nodo col pathname specificato, il major number specificato e l'i-esimo minor number specificato
	system(buff); // esecuzione del comando mknod appena definito
	sprintf(buff,"%s%d",path,i);
	pthread_create(&tid,NULL,the_thread,strdup(buff)); // creazione del thread che ci permette di lavorare con l'oggetto appena creato
     }

     pause();
     return 0;

}
