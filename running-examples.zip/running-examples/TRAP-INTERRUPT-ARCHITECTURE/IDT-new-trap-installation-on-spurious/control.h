#ifndef _CONTROL_H
#define _CONTROL_H

#define MOD_NAME "IDT ENTRY INSTALLER ON SPURIOUS"

int setup_my_irq(void);

void cleanup_my_irq(void);

#endif 
