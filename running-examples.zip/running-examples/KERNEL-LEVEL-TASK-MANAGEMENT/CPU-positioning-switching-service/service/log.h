#ifndef LOG_STRUCTURE
#define LOG_STRUCTURE

typedef struct _pf_log {
	int read;
	int write;
} pf_log;

#endif
