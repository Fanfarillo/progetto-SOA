#pragma once

//#define target_func "finish_task_switch"
#define target_func "sys_log_message"

typedef void h_func(void);
